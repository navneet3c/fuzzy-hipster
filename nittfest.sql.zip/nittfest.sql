-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 26, 2013 at 06:47 PM
-- Server version: 5.5.28
-- PHP Version: 5.3.10-1ubuntu3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nittfest`
--

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `configid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `value` varchar(1000) NOT NULL,
  PRIMARY KEY (`configid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`configid`, `name`, `value`) VALUES
(1, 'admin_login', 'admin;867747b5d2e125baadfc6d402878c34a8234185c');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `pageid` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `title` varchar(1500) NOT NULL,
  `type` varchar(300) NOT NULL,
  `scores` varchar(100) NOT NULL,
  `rank` int(11) NOT NULL,
  `language` enum('English','Hindi','Tamil') NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`pageid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='type 1 for scorable events' AUTO_INCREMENT=8 ;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`pageid`, `parentid`, `name`, `title`, `type`, `scores`, `rank`, `language`, `description`) VALUES
(1, 0, 'home', 'Home Page', '', '', 1, 'English', ''),
(2, 1, 'english', 'English Lits', '', '', 0, 'English', ''),
(3, 1, 'hindi', 'Hindi Lits', '', '', 1, 'Hindi', ''),
(4, 1, 'tamil', 'Tamil Lits', '', '', 2, 'Tamil', ''),
(5, 1, 'arts', 'Arts', '', '', 3, 'English', ''),
(6, 1, 'design', 'Design', '', '', 4, 'English', ''),
(7, 1, 'culturals', 'Culturals', '', '', 5, 'English', '');

-- --------------------------------------------------------

--
-- Table structure for table `score_details`
--

CREATE TABLE IF NOT EXISTS `score_details` (
  `updateid` int(11) NOT NULL AUTO_INCREMENT,
  `branchid` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `pageid` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `description` text NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`updateid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `score_log`
--

CREATE TABLE IF NOT EXISTS `score_log` (
  `serial` int(11) NOT NULL AUTO_INCREMENT,
  `branch` int(11) NOT NULL,
  `event` int(11) NOT NULL,
  `subevent` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `points` float(3,2) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`serial`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `score_main`
--

CREATE TABLE IF NOT EXISTS `score_main` (
  `branchid` int(11) NOT NULL AUTO_INCREMENT,
  `initial` varchar(100) NOT NULL,
  `name` varchar(300) NOT NULL,
  `culturals` float(3,2) NOT NULL,
  `english` float(3,2) NOT NULL,
  `hindi` float(3,2) NOT NULL,
  `tamil` float(3,2) NOT NULL,
  `arts` float(3,2) NOT NULL,
  `design` float(3,2) NOT NULL,
  PRIMARY KEY (`branchid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `score_main`
--

INSERT INTO `score_main` (`branchid`, `initial`, `name`, `culturals`, `english`, `hindi`, `tamil`, `arts`, `design`) VALUES
(1, 'Architecture', 'Architecture', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(2, 'Chemical', 'Chemical Engineering', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(3, 'Civil', 'Civil Engineering', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(4, 'Comp App', 'Computer Applications', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(5, 'CSE', 'Computer Science and Engineering', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(6, 'EEE', 'Electrical and Electronics Engineering', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(7, 'ECE', 'Electronics and Communication Engineering', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(8, 'ICE', 'Instrumentation and Control Engineering', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(9, 'DOM', 'Management Studies', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(10, 'Mech', 'Mechanical Engineering', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(11, 'MME', 'Metallurgical and Materials Engineering', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00),
(12, 'Prod', 'Production Engineering', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `sponsors`
--

CREATE TABLE IF NOT EXISTS `sponsors` (
  `sponsorid` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) NOT NULL,
  `type` varchar(300) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `url` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `rank` int(11) NOT NULL,
  PRIMARY KEY (`sponsorid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='type 1 for image' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `sponsors`
--

INSERT INTO `sponsors` (`sponsorid`, `parentid`, `type`, `name`, `url`, `image`, `rank`) VALUES
(1, 0, '', 'home', '', '', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
